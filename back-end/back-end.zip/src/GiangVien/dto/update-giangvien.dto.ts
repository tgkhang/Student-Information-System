import { IsOptional, IsString, IsDateString } from 'class-validator';

export class UpdateGiangVienDto {

  @IsOptional()
  @IsDateString()
  NgaySinh?: string;

  @IsOptional()
  @IsString()
  GioiTinh?: string;

  @IsOptional()
  @IsString()
  DiaChi?: string;

  @IsOptional()
  @IsString()
  SoDienThoai?: string;

  @IsOptional()
  @IsString()
  Khoa?: string;

  @IsOptional()
  @IsString()
  CCCD?: string;

  @IsOptional()
  @IsString()
  TrinhDo?: string;

  @IsOptional()
  @IsDateString()
  NgayCapNhat?: string;
}
