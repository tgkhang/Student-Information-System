import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AuthService } from 'src/auth/auth.service';
import { GiangVien, GiangVienDocument } from 'src/schemas/GiangVien.schema';
import { User, UserDocument } from 'src/schemas/user.schema';
import { UpdateGiangVienDto } from './dto/update-giangvien.dto';

@Injectable()
export class GiangVienService {
    constructor(
        @InjectModel(GiangVien.name) private readonly giangVienModel: Model<GiangVienDocument>,
        private readonly authService: AuthService,
    ){}

    async addTeacher(MaGV:string, HoTen: string, ChucVu: string): Promise<GiangVien>{
        const newTeacher = new this.giangVienModel({
            MaGV,
            HoTen,
            NgaySinh: null,
            GioiTinh: null,
            DiaChi: null,
            SoDienThoai: null,
            ChucVu,
            Khoa: null,
            CCCD: null,
            TrinhDo: null,
            NgayVaoLam: Date.now(),
        })
        return newTeacher.save();
    }

    private removeDiacritics(str: string): string {
        return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    }
    async generateUsername(fullName: string): Promise<string> {
        const normalizedFullName = this.removeDiacritics(fullName);
        const nameParts = normalizedFullName.trim().split(' ');
        const lastName = nameParts.pop();
        const initials = nameParts.map(word => word.charAt(0).toUpperCase()).join('');
        const count = await this.giangVienModel.countDocuments();
        const username = `${initials}${lastName}${(count + 1).toString().padStart(4, '0')}`;
        return username;
    }
    
    async deleteTeacher(MaGV: string): Promise<void> {
        try{
            const giangVien = await this.giangVienModel.findOne({MaGV});
            if (!giangVien) {
                throw new NotFoundException('Giảng viên không tồn tại.');
            }
            console.log(giangVien);
            const user = await this.authService.deleteUser(MaGV);
            await this.giangVienModel.findByIdAndDelete(giangVien._id);
        }
        catch(error)
        {
            throw new Error(`Xóa giảng viên thất bại: ${error.message}`);
        }
        
    }

    async updateGiangVien(MaGV: string, updateGiangVienDto: UpdateGiangVienDto) {
        const giangVien = await this.giangVienModel.findOne({ MaGV });
        if (!giangVien) {
            throw new NotFoundException('Giảng viên không tồn tại');
        }

        if (updateGiangVienDto.CCCD) {
            const existingCCCD = await this.giangVienModel.findOne({CCCD: updateGiangVienDto.CCCD});
            if (existingCCCD && existingCCCD.MaGV !== MaGV) {
                throw new BadRequestException('CCCD đã tồn tại');
            }
        }
    
        if (updateGiangVienDto.SoDienThoai) {
            const existingSDT = await this.giangVienModel.findOne({SoDienThoai: updateGiangVienDto.SoDienThoai,});
            if (existingSDT && existingSDT.MaGV !== MaGV) {
                throw new BadRequestException('Số điện thoại đã tồn tại');
            }
        }
        const updatedGiangVien = await this.giangVienModel.findOneAndUpdate(
        { MaGV },
        { $set: updateGiangVienDto, NgayCapNhat: new Date() },
        { new: true },
        );

        return updatedGiangVien;
    }

    async searchTeacher(query: string) {
        const giangVien = await this.giangVienModel.find({
            $or: [
                {HoTen: {$regex: query, $options: 'i'}},
                {MaGV: {$regex: query, $options:'i'}}
            ]

        })
        if (giangVien.length === 0)
            throw new NotFoundException('Không tìm thấy giảng viên.');

        return giangVien;

    }

}
