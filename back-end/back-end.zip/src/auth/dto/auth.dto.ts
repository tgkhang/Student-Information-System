export class AuthPayloadDto {
  username: string;
  password: string;
}

export class LoginDto {
  email: string;
  password: string;
}
