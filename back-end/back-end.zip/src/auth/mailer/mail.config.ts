export const mailConfig = {
  service: 'gmail',
  auth: {
    user: 'kvthuan22@clc.fitus.edu.vn',
    pass: 'akax mzyc fhhh zpgn',
  },
};
