import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { GiangVien, GiangVienDocument } from 'src/schemas/GiangVien.schema';

@Injectable()
export class GiangVienService {
    constructor(
        @InjectModel(GiangVien.name) private readonly GiangVienModel: Model<GiangVienDocument>,

    ){}

    async addTeacher(MaGV:string, HoTen: string, ChucVu: string): Promise<GiangVien>{
        const newTeacher = new this.GiangVienModel({
            MaGV,
            HoTen,
            NgaySinh: null,
            GioiTinh: null,
            DiaChi: null,
            SoDienThoai: null,
            ChucVu,
            Khoa: null,
            CCCD: null,
            TrinhDo: null,
        })
        return newTeacher.save();
    }
}
